import os, sys, subprocess

REQUIREMENTS = ["pillow", "lz4", "brotli", "python-snappy"]

def check_and_install():
    import importlib
    missing=[]
    for req in REQUIREMENTS:
        try:
            importlib.import_module(req if req!="pillow" else "PIL")
        except ImportError:
            missing.append(req)
    if missing:
        print("Installing missing packages:", missing)
        subprocess.check_call([sys.executable, "-m", "pip", "install"] + missing)

def main():
    check_and_install()
    script_path=os.path.join(os.path.dirname(__file__), "futuristic_vdb_ui.py")
    subprocess.run([sys.executable, script_path])

if __name__=="__main__":
    main()
