# Futuristic VDB Studio

## Run directly
python launcher.py

## Build standalone EXE
1. Install Python 3.9+
2. Run:
   pip install pillow lz4 brotli python-snappy pyinstaller
3. Double-click build.bat
4. Your EXE will be in `dist/FuturisticVDB.exe`
