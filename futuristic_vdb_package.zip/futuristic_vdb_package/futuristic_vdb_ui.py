# futuristic_vdb_studio.py
# Full restored + improved VDB Studio:
# - Click workspace file opens it in editor tab
# - 1s syntax refresh without resetting scroll/cursor
# - Clickable/underlined links & file paths (blue) open browser/explorer
# - Ctrl+S saves active file into VDB (and Save VDB menu)
# - Fully dark theme, no deletions of original functionality

import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import json
import io
import os
import traceback
import datetime
import re
import subprocess
import tempfile
import webbrowser
import sys
from vdb import pack_vdb, unpack_vdb
from encoders import encoders
from PIL import Image, ImageTk

# ---------------- Dark Theme Colors ----------------
BG_COLOR = "#1e1e2e"
SIDEBAR_BG = "#252526"
SIDEBAR_HOVER = "#33334a"
SIDEBAR_SELECTED = "#007acc"
TEXT_BG = "#1e1e2e"
TEXT_FG = "#d4d4d4"
BRACKET_COLOR = "#82FF82"
FUNC_COLOR = "#569cd6"
STRING_COLOR = "#d69d85"
KEYWORD_COLOR = "#c586c0"
NUMBER_COLOR = "#b5cea8"
SYNTAX_ERROR_COLOR = "#ff5555"
LINK_COLOR = "#4fa6ff"
TAB_BG = "#2d2d3c"
TAB_ACTIVE_BG = "#1e1e2e"
TAB_FG = "#d4d4d4"
TAB_ACTIVE_FG = "#ffffff"
BUTTON_BG = "#33334a"
BUTTON_FG = "#d4d4d4"
FONT = ("Fira Code", 11)

# ---------------- File Type Groups ----------------
TEXT_EXTENSIONS = [".py", ".js", ".lua", ".luau", ".jsx", ".sk", ".spec", ".bat", ".html", ".toc", ".txt", ".md"]
JSON_EXTENSIONS = [".json"]
BINARY_EXTENSIONS = [".jar", ".tar", ".pkg", ".vdb"]
IMAGE_EXTENSIONS = [".png", ".jpg", ".jpeg"]

# ---------------- Language definitions ----------------
LANGUAGES = {
    ".py": {"keywords":["def","class","if","else","elif","for","while","return","import","from","try","except","finally","with","as","pass","break","continue","in","is","and","or","not","lambda","yield","global","nonlocal","assert","del","raise"],"comment":"#"},
    ".js": {"keywords":["function","var","let","const","if","else","for","while","return","import","from","try","catch","finally","class","new","this","in","of","break","continue","switch","case","default"],"comment":"//"},
    ".jsx": {"keywords":["function","var","let","const","if","else","for","while","return","import","from","try","catch","finally","class","new","this","in","of","break","continue","switch","case","default"],"comment":"//"},
    ".html": {"keywords":["html","head","body","div","span","script","link","meta","title","style","input","button","form","h1","h2","h3","p","a","img","ul","li","table","tr","td"],"comment":"<!--"},
    ".lua": {"keywords":["function","end","if","then","else","elseif","for","while","do","return","local","break","continue","repeat","until"],"comment":"--"},
    ".luau": {"keywords":["function","end","if","then","else","elseif","for","while","do","return","local","break","continue","repeat","until"],"comment":"--"},
    ".json": {"keywords":[],"comment":None},
    ".toc": {"keywords":["##"],"comment":"##"},
    ".bat": {"keywords":["echo","set","if","else","goto","call","for","in","do"],"comment":"REM"},
    ".spec": {"keywords":[],"comment":"#"},
    ".sk": {"keywords":["on","broadcast","wait","if","else","set"],"comment":"#"},
    ".jar": {"keywords":[],"comment":None},
    ".tar": {"keywords":[],"comment":None},
    ".pkg": {"keywords":[],"comment":None},
    ".nbt": {"keywords":[],"comment":None}
}

# ---------------- Error Logging ----------------
def log_error(exc: Exception):
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        logs_folder = os.path.join(script_dir, "Logs")
        os.makedirs(logs_folder, exist_ok=True)
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        log_path = os.path.join(logs_folder, f"log_{timestamp}.json")
        log_data = {"timestamp": timestamp, "type": str(type(exc)), "message": str(exc), "traceback": traceback.format_exc()}
        with open(log_path, "w", encoding="utf-8") as f:
            json.dump(log_data, f, indent=2)
        print(f"Error logged to: {log_path}")
    except Exception as e:
        print("Failed to log error:", e)
        print(traceback.format_exc())

# ---------------- Syntax Checking (simple wrapper, used optionally) ----------------
def check_syntax(file_name, text):
    ext = os.path.splitext(file_name)[1].lower()
    try:
        if ext == ".py":
            compile(text, file_name, 'exec')
        elif ext == ".json":
            json.loads(text)
        elif ext in [".js", ".jsx"]:
            with tempfile.NamedTemporaryFile(delete=False, suffix=ext, mode="w", encoding="utf-8") as tmp:
                tmp.write(text)
                tmp_path = tmp.name
            result = subprocess.run(["node", "-c", tmp_path], capture_output=True, text=True)
            os.remove(tmp_path)
            if result.returncode != 0:
                return result.stderr
        elif ext in [".lua", ".luau"]:
            with tempfile.NamedTemporaryFile(delete=False, suffix=ext, mode="w", encoding="utf-8") as tmp:
                tmp.write(text)
                tmp_path = tmp.name
            cmd = ["luac","-p", tmp_path] if ext == ".lua" else ["luau","-c", tmp_path]
            result = subprocess.run(cmd, capture_output=True, text=True)
            os.remove(tmp_path)
            if result.returncode != 0:
                return result.stderr
        elif ext == ".html":
            tags = re.findall(r"<(/?)(\w+)[^>]*>", text)
            stack = []
            for slash, tag in tags:
                if not slash:
                    stack.append(tag)
                elif stack and stack[-1] == tag:
                    stack.pop()
                else:
                    return f"Unmatched tag: {tag}"
            if stack:
                return f"Unmatched tags: {stack}"
        return None
    except Exception as e:
        return str(e)

# ---------------- Tab ----------------
class TabFrame(tk.Frame):
    def __init__(self, parent, text, close_callback, **kwargs):
        super().__init__(parent, bg=TAB_BG, **kwargs)
        self.close_callback = close_callback
        self.text = text
        self.label = tk.Label(self, text=text, bg=TAB_BG, fg=TAB_FG, font=FONT)
        self.label.pack(side="left", padx=6, pady=3)
        self.btn_close = tk.Button(self, text="✕", command=self.close, bg=BUTTON_BG, fg="red", bd=0, font=("Fira Code",10), activebackground=TAB_ACTIVE_BG)
        self.btn_close.pack(side="right", padx=4)
        self.label.bind("<Button-1>", self.on_click)
        self.active = False

    def close(self):
        self.close_callback(self)

    def on_click(self, event=None):
        # delegate to parent container which implements set_active_tab
        try:
            self.master.set_active_tab(self)
        except Exception:
            pass

    def set_active(self, active=True):
        self.active = active
        if active:
            self.configure(bg=TAB_ACTIVE_BG)
            self.label.configure(bg=TAB_ACTIVE_BG, fg=TAB_ACTIVE_FG)
            self.btn_close.configure(bg=TAB_ACTIVE_BG)
        else:
            self.configure(bg=TAB_BG)
            self.label.configure(bg=TAB_BG, fg=TAB_FG)
            self.btn_close.configure(bg=BUTTON_BG)

# ---------------- Main VDB Studio ----------------
class VDBStudio:
    def __init__(self, root):
        self.root = root
        self.root.title("Futuristic VDB Studio")
        self.root.geometry("1000x600")
        self.root.configure(bg=BG_COLOR)

        self.tree_images = {}
        style = ttk.Style()
        style.theme_use('clam')
        style.configure("Treeview", background=SIDEBAR_BG, foreground=TEXT_FG, fieldbackground=SIDEBAR_BG, font=FONT)
        style.map('Treeview', background=[('selected', SIDEBAR_SELECTED)], foreground=[('selected', TAB_ACTIVE_FG)])

        # layout
        self.pane = ttk.PanedWindow(root, orient="horizontal")
        self.pane.pack(fill="both", expand=True)

        # workspace tree
        self.tree = ttk.Treeview(self.pane)
        self.tree.heading("#0", text="Workspace Explorer", anchor="w")
        self.tree.bind("<Motion>", self.on_hover)
        self.tree.bind("<Leave>", self.on_leave)
        # open file on single-click selection
        self.tree.bind("<<TreeviewSelect>>", self.open_from_workspace)
        self.tree.tag_configure("hover", background=SIDEBAR_HOVER)
        self.pane.add(self.tree, weight=1)

        # editor area
        self.editor_container = tk.Frame(self.pane, bg=BG_COLOR)
        self.tab_bar = tk.Frame(self.editor_container, bg=TAB_BG)
        self.tab_bar.pack(fill="x", side="top")
        self.tab_pages = {}  # fname -> {"tab": TabFrame, "widget": Text}
        self.preview_container = tk.Frame(self.editor_container, bg=TEXT_BG, bd=2, relief="flat")
        self.preview_container.pack(fill="both", expand=True)
        self.pane.add(self.editor_container, weight=3)

        # menu
        menubar = tk.Menu(root, bg=SIDEBAR_BG, fg=TEXT_FG)
        filemenu = tk.Menu(menubar, tearoff=0, bg=SIDEBAR_BG, fg=TEXT_FG)
        filemenu.add_command(label="New VDB", command=self.new_vdb)
        filemenu.add_command(label="Open VDB", command=self.open_vdb)
        filemenu.add_command(label="Save VDB", command=self.save_vdb)
        filemenu.add_command(label="Extract VDB", command=self.extract_vdb)
        menubar.add_cascade(label="File", menu=filemenu)
        root.config(menu=menubar)

        # state
        self.vdb_files = {}      # filename -> bytes
        self.vdb_path = None     # last opened VDB path
        self.tk_img = None
        self.hovered_item = None
        self.active_file = None  # filename of active tab

        # periodic refresh for syntax highlighting
        self.root.after(1000, self.refresh_syntax)
        # ctrl+s
        self.root.bind_all("<Control-s>", lambda e: self.save_active_file())

    # ---------- Sidebar hover ----------
    def on_hover(self, event):
        iid = self.tree.identify_row(event.y)
        if iid != self.hovered_item:
            if self.hovered_item:
                self.tree.item(self.hovered_item, tags=())
            if iid:
                self.tree.item(iid, tags=("hover",))
            self.hovered_item = iid

    def on_leave(self, event):
        if self.hovered_item:
            self.tree.item(self.hovered_item, tags=())
        self.hovered_item = None

    # ---------- VDB operations ----------
    def new_vdb(self):
        try:
            files = filedialog.askopenfilenames()
            if not files:
                return
            out = filedialog.asksaveasfilename(defaultextension=".vdb")
            if not out:
                return
            encoder = "zlib"
            packed = pack_vdb([(os.path.basename(f), open(f,"rb").read()) for f in files], encoder)
            with open(out,"wb") as f:
                f.write(packed)
            messagebox.showinfo("Success","VDB created!")
        except Exception as e:
            log_error(e)
            messagebox.showerror("Error", str(e))

    def open_vdb(self):
        try:
            path = filedialog.askopenfilename(filetypes=[("VDB","*.vdb")])
            if not path:
                return
            self.vdb_path = path
            data = open(path,"rb").read()
            files = unpack_vdb(data)
            # clear tree & tabs
            for i in self.tree.get_children():
                self.tree.delete(i)
            # close tabs
            for info in list(self.tab_pages.values()):
                try:
                    info["widget"].destroy()
                    info["tab"].destroy()
                except:
                    pass
            self.tab_pages.clear()
            self.vdb_files = {f["filename"]: f["data"] for f in files}
            for fname in self.vdb_files.keys():
                self.tree.insert("", "end", text=fname)
        except Exception as e:
            log_error(e)
            messagebox.showerror("Error", str(e))

    def save_vdb(self):
        try:
            if not self.vdb_files:
                messagebox.showinfo("Info", "No files to save.")
                return
            out = self.vdb_path or filedialog.asksaveasfilename(defaultextension=".vdb")
            if not out:
                return
            packed = pack_vdb([(fname, data) for fname, data in self.vdb_files.items()], "zlib")
            with open(out, "wb") as f:
                f.write(packed)
            self.vdb_path = out
            messagebox.showinfo("Saved", "VDB saved successfully")
        except Exception as e:
            log_error(e)
            messagebox.showerror("Error", str(e))

    def extract_vdb(self):
        try:
            if not self.vdb_files:
                return
            outdir = filedialog.askdirectory()
            if not outdir:
                return
            for fname, data in self.vdb_files.items():
                with open(os.path.join(outdir, fname), "wb") as f:
                    f.write(data)
            messagebox.showinfo("Done", "Extracted all files")
        except Exception as e:
            log_error(e)
            messagebox.showerror("Error", str(e))

    # ---------- Tab management ----------
    def open_tab(self, fname, data_bytes):
        # open or focus an existing tab
        if fname in self.tab_pages:
            self.set_active_tab(self.tab_pages[fname]["tab"])
            return

        # create new tab
        tab = TabFrame(self.tab_bar, fname, self.close_tab)
        tab.pack(side="left", padx=2, pady=2)

        # create text widget with scrollbars inside preview_container
        frame = tk.Frame(self.preview_container, bg=TEXT_BG)
        # vertical + horizontal scrollbars
        vs = tk.Scrollbar(frame, orient="vertical")
        hs = tk.Scrollbar(frame, orient="horizontal")
        text_widget = tk.Text(frame, wrap="none", bg=TEXT_BG, fg=TEXT_FG, insertbackground=TAB_ACTIVE_FG,
                              font=FONT, bd=0, highlightthickness=0, yscrollcommand=vs.set, xscrollcommand=hs.set)
        vs.config(command=text_widget.yview)
        hs.config(command=text_widget.xview)
        vs.pack(side="right", fill="y")
        hs.pack(side="bottom", fill="x")
        text_widget.pack(fill="both", expand=True)
        frame.pack_forget()  # we'll pack the active one

        # tag configs
        text_widget.tag_config("bracket", foreground=BRACKET_COLOR)
        text_widget.tag_config("func", foreground=FUNC_COLOR)
        text_widget.tag_config("string", foreground=STRING_COLOR)
        text_widget.tag_config("keyword", foreground=KEYWORD_COLOR)
        text_widget.tag_config("number", foreground=NUMBER_COLOR)
        text_widget.tag_config("syntax_error", foreground=SYNTAX_ERROR_COLOR)
        text_widget.tag_config("link", foreground=LINK_COLOR, underline=True)
        # clicking links
        text_widget.tag_bind("link", "<Button-1>", self.on_link_click)
        # change cursor on hover for links
        text_widget.tag_bind("link", "<Enter>", lambda e: text_widget.config(cursor="hand2"))
        text_widget.tag_bind("link", "<Leave>", lambda e: text_widget.config(cursor=""))

        # store
        self.tab_pages[fname] = {"tab": tab, "widget": text_widget, "frame": frame}

        # insert text WITHOUT destroying widget content (we're fresh), then highlight
        try:
            text = data_bytes.decode("utf-8", errors="ignore")
        except Exception:
            text = data_bytes.decode("latin-1", errors="ignore")
        text_widget.delete("1.0", "end")
        text_widget.insert("1.0", text)
        # run initial syntax highlighting (non-destructive)
        self.apply_highlight_non_destructive(text_widget, fname, text)
        # show it
        self.set_active_tab(tab)

    def set_active_tab(self, tab):
        # Hide all frames
        for fname, info in self.tab_pages.items():
            info["frame"].pack_forget()
            info["tab"].set_active(False)
        # Find and show selected
        for fname, info in self.tab_pages.items():
            if info["tab"] == tab:
                info["frame"].pack(fill="both", expand=True)
                info["tab"].set_active(True)
                self.active_file = fname
                break

    def close_tab(self, tab):
        for fname, info in list(self.tab_pages.items()):
            if info["tab"] == tab:
                # destroy widgets and remove mapping
                try:
                    info["frame"].destroy()
                except:
                    pass
                try:
                    info["tab"].destroy()
                except:
                    pass
                del self.tab_pages[fname]
                break
        # select another tab if any
        if self.tab_pages:
            next_tab = next(iter(self.tab_pages.values()))["tab"]
            self.set_active_tab(next_tab)
        else:
            self.active_file = None

    # ---------- Open from workspace ----------
    def open_from_workspace(self, event):
        sel = self.tree.selection()
        if not sel:
            return
        fname = self.tree.item(sel[0], "text")
        data = self.vdb_files.get(fname)
        if data is not None:
            self.open_tab(fname, data)

    # ---------- Save system ----------
    def save_file(self, fname):
        if fname not in self.tab_pages:
            return
        widget = self.tab_pages[fname]["widget"]
        text = widget.get("1.0", "end-1c")
        self.vdb_files[fname] = text.encode("utf-8")

    def save_active_file(self):
        if self.active_file:
            self.save_file(self.active_file)
            # save to same VDB path if exists, else ask
            self.save_vdb()

    # ---------- Syntax highlighting (non-destructive) ----------
    # This function DOES NOT delete widget content or change view position.
    def apply_highlight_non_destructive(self, widget, fname, text=None):
        """
        Apply tags to 'widget' based on 'text'. Preserves scroll/cursor.
        If text omitted, reads from widget.
        """
        try:
            # capture view/cursor
            try:
                yview = widget.yview()
                xview = widget.xview()
                insert_index = widget.index("insert")
            except Exception:
                yview = None
                xview = None
                insert_index = None

            if text is None:
                text = widget.get("1.0", "end-1c")

            # remove tags
            for tag in ("bracket", "func", "string", "keyword", "number", "syntax_error", "link"):
                widget.tag_remove(tag, "1.0", "end")

            # prepare patterns
            ext = os.path.splitext(fname)[1].lower()
            lang = LANGUAGES.get(ext, LANGUAGES[".py"])
            keywords = lang.get("keywords", [])

            # compile regexes
            bracket_re = re.compile(r"[\[\]\{\}\(\)]")
            string_re = re.compile(r'(\".*?\"|\'.*?\')', re.DOTALL)
            keyword_re = re.compile(r"\b(" + "|".join(re.escape(k) for k in keywords) + r")\b") if keywords else None
            number_re = re.compile(r"\b\d+(\.\d+)?\b")
            func_re = re.compile(r"\b\w+(?=\()")
            # url/path pattern - reasonably permissive
            url_re = re.compile(r"https?://[^\s'\"<>]+")
            # Windows paths like C:\foo\bar or Unix /foo/bar or ./rel/path
            path_re = re.compile(r"""(?x)
                (?:[A-Za-z]:[\\/][\w\-.\\/~]+)   # C:\something or C:/something
                |(?:/[\w\-.\\/~]+)               # /usr/bin or /path
                |(?:\.\.?[\\/][\w\-.\\/~]+)      # ./rel/path or ../path
            """)

            # find and tag matches by scanning text once (efficiency)
            # We'll gather matches then add tags — this avoids moving the widget content.
            matches = []
            for m in bracket_re.finditer(text):
                matches.append( (m.start(), m.end(), "bracket") )
            for m in string_re.finditer(text):
                matches.append( (m.start(), m.end(), "string") )
            if keyword_re:
                for m in keyword_re.finditer(text):
                    matches.append( (m.start(), m.end(), "keyword") )
            for m in number_re.finditer(text):
                matches.append( (m.start(), m.end(), "number") )
            for m in func_re.finditer(text):
                matches.append( (m.start(), m.end(), "func") )
            for m in url_re.finditer(text):
                matches.append( (m.start(), m.end(), "link") )
            for m in path_re.finditer(text):
                matches.append( (m.start(), m.end(), "link") )

            # sort matches by start to be deterministic
            matches.sort(key=lambda x: x[0])

            # apply tags
            for start, end, tag in matches:
                start_index = f"1.0+{start}c"
                end_index = f"1.0+{end}c"
                widget.tag_add(tag, start_index, end_index)

            # ensure tag configs (colors, underline)
            widget.tag_config("bracket", foreground=BRACKET_COLOR)
            widget.tag_config("func", foreground=FUNC_COLOR)
            widget.tag_config("string", foreground=STRING_COLOR)
            widget.tag_config("keyword", foreground=KEYWORD_COLOR)
            widget.tag_config("number", foreground=NUMBER_COLOR)
            widget.tag_config("syntax_error", foreground=SYNTAX_ERROR_COLOR)
            widget.tag_config("link", foreground=LINK_COLOR, underline=True)

            # restore view & cursor
            if yview is not None:
                try:
                    widget.yview_moveto(yview[0])
                except Exception:
                    pass
            if xview is not None:
                try:
                    widget.xview_moveto(xview[0])
                except Exception:
                    pass
            if insert_index is not None:
                try:
                    widget.mark_set("insert", insert_index)
                except Exception:
                    pass
        except Exception as e:
            # never crash the UI on highlighting problems
            log_error(e)

    # Wrapper called periodically
    def refresh_syntax(self):
        try:
            for fname, info in list(self.tab_pages.items()):
                try:
                    widget = info["widget"]
                    # get current text (may be large; OK)
                    text = widget.get("1.0", "end-1c")
                    # apply highlight without disturbing scroll/position
                    self.apply_highlight_non_destructive(widget, fname, text)
                except Exception:
                    pass
        finally:
            # schedule next refresh
            self.root.after(1000, self.refresh_syntax)

    # ---------- Link click handler ----------
    def on_link_click(self, event):
        widget = event.widget
        # index clicked
        try:
            idx = widget.index(f"@{event.x},{event.y}")
            # get wordstart/wordend (tk word boundaries)
            start = widget.index(f"{idx} wordstart")
            end = widget.index(f"{idx} wordend")
            word = widget.get(start, end).strip()
            if not word:
                # try expand by tag range
                tags = widget.tag_names(idx)
                if "link" in tags:
                    ranges = widget.tag_ranges("link")
                    # find which range contains idx
                    for i in range(0, len(ranges), 2):
                        if widget.compare(ranges[i], "<=", idx) and widget.compare(idx, "<", ranges[i+1]):
                            word = widget.get(ranges[i], ranges[i+1]).strip()
                            break
            if not word:
                return
            if word.startswith("http://") or word.startswith("https://"):
                webbrowser.open(word)
            else:
                # treat as file path
                # try to expand environment variables and user
                path = os.path.expandvars(os.path.expanduser(word))
                if os.path.exists(path):
                    try:
                        if sys.platform.startswith("win"):
                            # open explorer and select if file
                            if os.path.isfile(path):
                                subprocess.run(["explorer", "/select,", path])
                            else:
                                subprocess.run(["explorer", path])
                        elif sys.platform == "darwin":
                            subprocess.run(["open", path])
                        else:
                            subprocess.run(["xdg-open", path])
                    except Exception as e:
                        messagebox.showerror("Error", f"Failed to open path:\n{e}")
                else:
                    messagebox.showerror("Path not found", f"File or folder not found:\n{path}")
        except Exception as e:
            log_error(e)

# ---------------- Main ----------------
if __name__ == "__main__":
    try:
        root = tk.Tk()
        root.configure(bg=BG_COLOR)
        app = VDBStudio(root)
        root.mainloop()
    except Exception as e:
        log_error(e)
        print("An error occurred. Check Logs folder for details.")
        print("\nPress Enter to exit...")
        input()
