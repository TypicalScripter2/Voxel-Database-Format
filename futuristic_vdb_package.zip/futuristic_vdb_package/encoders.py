import base64, zlib, bz2, lzma, gzip, codecs

try: import lz4.frame as lz4
except: lz4=None
try: import brotli
except: brotli=None
try: import snappy
except: snappy=None

def rot13_enc(data: bytes) -> bytes:
    return codecs.encode(data.decode('utf-8'), 'rot_13').encode()
def rot13_dec(data: bytes) -> bytes:
    return codecs.decode(data.decode('utf-8'), 'rot_13').encode()

def atbash_enc(data: bytes) -> bytes:
    text=data.decode('utf-8')
    trans=str.maketrans("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ",
                        "zyxwvutsrqponmlkjihgfedcbaZYXWVUTSRQPONMLKJIHGFEDCBA")
    return text.translate(trans).encode()
def atbash_dec(data: bytes) -> bytes: return atbash_enc(data)

encoders = {
    "base64": (lambda d: base64.b64encode(d), lambda d: base64.b64decode(d)),
    "base32": (lambda d: base64.b32encode(d), lambda d: base64.b32decode(d)),
    "zlib": (lambda d: zlib.compress(d), lambda d: zlib.decompress(d)),
    "bz2": (lambda d: bz2.compress(d), lambda d: bz2.decompress(d)),
    "lzma": (lambda d: lzma.compress(d), lambda d: lzma.decompress(d)),
    "gzip": (lambda d: gzip.compress(d), lambda d: gzip.decompress(d)),
    "rot13": (rot13_enc, rot13_dec),
    "atbash": (atbash_enc, atbash_dec),
}

if lz4:
    encoders["lz4"] = (lambda d: lz4.compress(d), lambda d: lz4.decompress(d))
if brotli:
    encoders["brotli"] = (lambda d: brotli.compress(d), lambda d: brotli.decompress(d))
if snappy:
    encoders["snappy"] = (lambda d: snappy.compress(d), lambda d: snappy.decompress(d))
