# vdb.py
# Futuristic VDB — multi-layer custom encoder/decoder
# External API:
#   pack_vdb(list_of_tuples[(filename, bytes)]) -> bytes (VDB file contents)
#   unpack_vdb(bytes) -> list_of_dicts [{"filename": name, "data": bytes}, ...]
#
# Improvements over simple XOR:
#  - PBKDF2 key derivation (hashlib)
#  - AES-GCM authenticated encryption when PyCryptodome is available
#  - Fallback authenticated XOR-stream + HMAC if AES unavailable
#  - base85 encoding to make raw bytes non-obvious
#  - custom header with version so only this UI can decode
#
# IMPORTANT: For best security install PyCryptodome:
#   pip install pycryptodome
#
# Keep SECRET_PASSPHRASE secret — it's used to derive encryption keys.

import os
import struct
import base64
import hashlib
import hmac
import secrets

# Try to use AES-GCM from PyCryptodome for authenticated encryption
try:
    from Crypto.Cipher import AES
    from Crypto.Random import get_random_bytes
    HAVE_AESGCM = True
except Exception:
    HAVE_AESGCM = False

# Parameters (tune if you understand implications)
HEADER_MAGIC = b"FVDB"         # Futuristic VDB
VERSION = 2                    # version number (so future formats possible)
PBKDF2_ITER = 200_000          # iterations for PBKDF2 (slow enough, increase if desired)
SALT_SIZE = 16                 # bytes
AES_KEY_SIZE = 32              # 256-bit AES key
GCM_NONCE_SIZE = 12            # recommended nonce size for GCM
HMAC_SIZE = 32                 # SHA256 HMAC

# Private passphrase (change this to your own long secret; keep offline)
# You can also replace usage to obtain passphrase from environment or a file.
SECRET_PASSPHRASE = b"VDBEncodePass174"

# ---------- Helpers ----------
def _derive_keys(salt: bytes):
    """
    Derive keys from SECRET_PASSPHRASE and salt.
    Returns (enc_key, mac_key) both bytes.
    """
    # Use PBKDF2-HMAC-SHA256 to derive a master key
    master = hashlib.pbkdf2_hmac("sha256", SECRET_PASSPHRASE, salt, PBKDF2_ITER, dklen=AES_KEY_SIZE * 2)
    return master[:AES_KEY_SIZE], master[AES_KEY_SIZE:]  # enc_key, mac_key

def _hmac_sha256(key: bytes, data: bytes) -> bytes:
    return hmac.new(key, data, hashlib.sha256).digest()

def _xor_stream_encrypt(key: bytes, nonce: bytes, data: bytes) -> bytes:
    """
    XOR-stream encryption using HMAC-derived keystream.
    This is a fallback when AES-GCM isn't available.
    Not as secure as AES-GCM, but keyed by derived key+nonce.
    """
    out = bytearray(len(data))
    block = 0
    pos = 0
    while pos < len(data):
        counter = block.to_bytes(8, "big")
        digest = hashlib.pbkdf2_hmac("sha256", key + nonce + counter, b"", 1, dklen=32)
        # XOR up to 32 bytes
        chunk = data[pos:pos+32]
        for i, b in enumerate(chunk):
            out[pos + i] = b ^ digest[i]
        pos += len(chunk)
        block += 1
    return bytes(out)

def _xor_stream_decrypt(key: bytes, nonce: bytes, data: bytes) -> bytes:
    # XOR is symmetrical
    return _xor_stream_encrypt(key, nonce, data)

# ---------- High-level encode / decode helpers ----------
def encrypt_payload(plaintext: bytes) -> bytes:
    """
    Returns an encrypted blob (binary), ready to be embedded in VDB.
    Structure (version 2):
      [version:1][salt_len:1][salt][method:1]
      if AESGCM:
        [nonce_len:1][nonce][cipher_len:4][ciphertext][tag_len:1][tag]
      else (fallback):
        [nonce_len:1][nonce][cipher_len:4][ciphertext][hmac:32]
    The outer VDB packer may then base85-encode this blob.
    """
    salt = secrets.token_bytes(SALT_SIZE)
    enc_key, mac_key = _derive_keys(salt)

    if HAVE_AESGCM:
        # AES-GCM path (authenticated encryption)
        nonce = get_random_bytes(GCM_NONCE_SIZE)
        cipher = AES.new(enc_key, AES.MODE_GCM, nonce=nonce)
        ciphertext, tag = cipher.encrypt_and_digest(plaintext)
        # Build blob
        blob = bytearray()
        blob += VERSION.to_bytes(1, "big")
        blob += (len(salt)).to_bytes(1, "big") + salt
        blob += (1).to_bytes(1, "big")  # method = 1 -> AES-GCM
        blob += (len(nonce)).to_bytes(1, "big") + nonce
        blob += struct.pack("<I", len(ciphertext)) + ciphertext
        blob += (len(tag)).to_bytes(1, "big") + tag
        return bytes(blob)
    else:
        # Fallback XOR-stream + HMAC
        nonce = secrets.token_bytes(12)  # arbitrary nonce length
        ciphertext = _xor_stream_encrypt(enc_key, nonce, plaintext)
        tag = _hmac_sha256(mac_key, ciphertext)
        blob = bytearray()
        blob += VERSION.to_bytes(1, "big")
        blob += (len(salt)).to_bytes(1, "big") + salt
        blob += (2).to_bytes(1, "big")  # method = 2 -> XOR+HMAC
        blob += (len(nonce)).to_bytes(1, "big") + nonce
        blob += struct.pack("<I", len(ciphertext)) + ciphertext
        blob += tag  # 32 bytes
        return bytes(blob)

def decrypt_payload(blob: bytes) -> bytes:
    """
    Reverse of encrypt_payload. Raises ValueError if auth fails / malformed.
    """
    try:
        p = 0
        version = blob[p]; p += 1
        salt_len = blob[p]; p += 1
        salt = blob[p:p+salt_len]; p += salt_len
        method = blob[p]; p += 1
        enc_key, mac_key = _derive_keys(salt)
        nonce_len = blob[p]; p += 1
        nonce = blob[p:p+nonce_len]; p += nonce_len
        cipher_len = struct.unpack("<I", blob[p:p+4])[0]; p += 4
        ciphertext = blob[p:p+cipher_len]; p += cipher_len

        if method == 1 and HAVE_AESGCM:
            tag_len = blob[p]; p += 1
            tag = blob[p:p+tag_len]; p += tag_len
            # decrypt with AES-GCM
            cipher = AES.new(enc_key, AES.MODE_GCM, nonce=nonce)
            # AES GCM expects to verify tag at decrypt time
            plaintext = cipher.decrypt_and_verify(ciphertext, tag)
            return plaintext
        elif method == 2:
            # fallback XOR + HMAC (verify HMAC)
            tag = blob[p:p+HMAC_SIZE]; p += HMAC_SIZE
            expected = _hmac_sha256(mac_key, ciphertext)
            if not hmac.compare_digest(expected, tag):
                raise ValueError("HMAC mismatch — data tampered or wrong key")
            plaintext = _xor_stream_decrypt(enc_key, nonce, ciphertext)
            return plaintext
        else:
            raise ValueError("Unsupported method or required crypto library missing.")
    except Exception as e:
        raise ValueError(f"Failed to decrypt payload: {e}")

# ---------- VDB pack/unpack ----------
def pack_vdb(files, encoder="custom"):
    """
    Pack list of (filename, bytes) into a single VDB bytes object.
    files: iterable of (filename, data_bytes)
    Returns: bytes
    """
    # structure:
    # HEADER_MAGIC (4) | uint8: version | blob_len:uint32 | blob (base85) | repeated entries...
    # Simpler: create a combined plain payload of entries then encrypt that payload,
    # then base85 encode and return header + encoded.
    #
    entries = bytearray()
    for fname, fdata in files:
        if isinstance(fname, str):
            fname_b = fname.encode("utf-8")
        else:
            fname_b = fname
        entries += struct.pack("<I", len(fname_b)) + fname_b
        entries += struct.pack("<I", len(fdata)) + fdata

    # encrypt the whole entries blob
    encrypted_blob = encrypt_payload(bytes(entries))
    # base85 encode
    encoded = base64.b85encode(encrypted_blob)

    # final structure: magic + version_byte + uint32(len(encoded)) + encoded
    out = bytearray()
    out += HEADER_MAGIC
    out += VERSION.to_bytes(1, "big")
    out += struct.pack("<I", len(encoded))
    out += encoded
    return bytes(out)

def unpack_vdb(data: bytes):
    """
    Unpack VDB bytes created by pack_vdb.
    Returns a list of {"filename": str, "data": bytes}
    """
    try:
        p = 0
        if len(data) < 4:
            raise ValueError("Data too short")
        magic = data[p:p+4]; p += 4
        if magic != HEADER_MAGIC:
            raise ValueError("Not a Futuristic VDB (bad magic)")
        file_version = data[p]; p += 1
        enc_len = struct.unpack("<I", data[p:p+4])[0]; p += 4
        encoded = data[p:p+enc_len]; p += enc_len
        encrypted_blob = base64.b85decode(encoded)
        # decrypt payload
        payload = decrypt_payload(encrypted_blob)
        # parse entries
        q = 0
        results = []
        while q < len(payload):
            name_len = struct.unpack("<I", payload[q:q+4])[0]; q += 4
            name = payload[q:q+name_len].decode("utf-8"); q += name_len
            dlen = struct.unpack("<I", payload[q:q+4])[0]; q += 4
            fdata = payload[q:q+dlen]; q += dlen
            results.append({"filename": name, "data": fdata})
        return results
    except Exception as e:
        raise ValueError(f"Failed to unpack VDB: {e}")